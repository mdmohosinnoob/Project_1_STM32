#include "stm32f446xx.h"
#include <stdint.h>
#include <stdio.h>

volatile uint32_t ms_count = 0;

static void SystemClock_Config(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_PWREN;
    PWR->CR      |= PWR_CR_VOS;

    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY));

    FLASH->ACR  = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_PRFTEN;
    FLASH->ACR &= ~FLASH_ACR_LATENCY;
    FLASH->ACR |=  FLASH_ACR_LATENCY_5WS;

    RCC->PLLCFGR  = 0;
    RCC->PLLCFGR |= (8U   << RCC_PLLCFGR_PLLM_Pos);
    RCC->PLLCFGR |= (180U << RCC_PLLCFGR_PLLN_Pos);
    RCC->PLLCFGR |= (0U   << RCC_PLLCFGR_PLLP_Pos);
    RCC->PLLCFGR |= RCC_PLLCFGR_PLLSRC_HSI;
    RCC->PLLCFGR |= (4U   << RCC_PLLCFGR_PLLQ_Pos);

    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    PWR->CR |= PWR_CR_ODEN;
    while (!(PWR->CSR & PWR_CSR_ODRDY));
    PWR->CR |= PWR_CR_ODSWEN;
    while (!(PWR->CSR & PWR_CSR_ODSWRDY));

    RCC->CFGR |= RCC_CFGR_HPRE_DIV1;
    RCC->CFGR |= RCC_CFGR_PPRE1_DIV4;
    RCC->CFGR |= RCC_CFGR_PPRE2_DIV2;

    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |=  RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
}

static void USART2_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;

    GPIOA->MODER  &= ~(3U << (2*2));
    GPIOA->MODER  |=  (2U << (2*2));
    GPIOA->AFR[0] &= ~(0xFU << (4*2));
    GPIOA->AFR[0] |=  (7U   << (4*2));

    USART2->BRR = (24U << 4) | 7U;
    USART2->CR1 = USART_CR1_TE | USART_CR1_UE;
}

static void USART2_SendString(const char *s)
{
    while (*s) {
        while (!(USART2->SR & USART_SR_TXE)) {}
        USART2->DR = (uint8_t)(*s++);
    }
    while (!(USART2->SR & USART_SR_TC)) {}
}

static void TIM3_Init(void)
{
    RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
    __NOP(); __NOP();

    TIM3->CR1  &= ~TIM_CR1_CEN;
    TIM3->PSC   = 89U;
    TIM3->ARR   = 999U;
    TIM3->EGR   = TIM_EGR_UG;
    TIM3->SR    = 0U;
    TIM3->DIER |= TIM_DIER_UIE;

    NVIC_SetPriority(TIM3_IRQn, 0U);
    NVIC_EnableIRQ(TIM3_IRQn);

    TIM3->CR1 |= TIM_CR1_CEN;
}

void TIM3_IRQHandler(void)
{
    if (TIM3->SR & TIM_SR_UIF) {
        TIM3->SR &= ~TIM_SR_UIF;
        ms_count++;
    }
}

static void delay_ms(uint32_t ms)
{
    uint32_t start = ms_count;
    while ((ms_count - start) < ms) {}
}

/*
 * TIM2 CH1 on PA0 (AF1) — 50 Hz PWM
 *
 * fTIM2_CLK = 90 MHz
 * PSC = 89  -> tick_freq = 1,000,000 Hz (1 us per tick)
 * ARR = 19999 -> period = 20,000 us = 20 ms -> 50 Hz
 *
 * CCR1 = pulse_width_us * 1  (since 1 tick = 1 us)
 *
 * 0°   -> 1000 us -> CCR1 = 1000
 * 90°  -> 1500 us -> CCR1 = 1500
 * 180° -> 2000 us -> CCR1 = 2000
 */
#define TIM2_PSC   89U
#define TIM2_ARR   19999U
#define TIM2_FREQ  1000000UL

static void TIM2_Servo_Init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
    __NOP(); __NOP();

    GPIOA->MODER  &= ~(3U << (0*2));
    GPIOA->MODER  |=  (2U << (0*2));
    GPIOA->OTYPER  &= ~(1U << 0);
    GPIOA->OSPEEDR |=  (3U << (0*2));
    GPIOA->PUPDR   &= ~(3U << (0*2));

    GPIOA->AFR[0] &= ~(0xFU << (4*0));
    GPIOA->AFR[0] |=  (1U   << (4*0));

    TIM2->CR1  &= ~TIM_CR1_CEN;
    TIM2->PSC   = TIM2_PSC;
    TIM2->ARR   = TIM2_ARR;

    TIM2->CCMR1 &= ~TIM_CCMR1_OC1M;
    TIM2->CCMR1 |=  TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2;
    TIM2->CCMR1 |=  TIM_CCMR1_OC1PE;

    TIM2->CCR1  = 1500U;

    TIM2->CCER |=  TIM_CCER_CC1E;
    TIM2->CCER &= ~TIM_CCER_CC1P;

    TIM2->CR1  |= TIM_CR1_ARPE;

    TIM2->EGR   = TIM_EGR_UG;
    TIM2->SR    = 0U;

    TIM2->CR1  |= TIM_CR1_CEN;
}

static void Servo_SetAngle(uint8_t angle)
{
    if (angle > 180U) angle = 180U;
    uint32_t pulse_us = 1000U + ((uint32_t)angle * 1000U) / 180U;
    TIM2->CCR1 = pulse_us;
}

static uint32_t Servo_AngleToPulse(uint8_t angle)
{
    if (angle > 180U) angle = 180U;
    return 1000U + ((uint32_t)angle * 1000U) / 180U;
}

int main(void)
{
    char buf[80];

    SystemClock_Config();
    USART2_Init();
    TIM3_Init();
    TIM2_Servo_Init();

    USART2_SendString("\r\n==========================================\r\n");
    USART2_SendString("  Task 6B: Servo Control - STM32F446RE\r\n");
    USART2_SendString("  PA0, TIM2 CH1 (AF1), 50Hz PWM\r\n");
    USART2_SendString("  PSC=89, ARR=19999, tick=1us\r\n");
    USART2_SendString("==========================================\r\n");

    USART2_SendString("\r\n-- Servo Sweep: 0 to 180 degrees --\r\n");
    USART2_SendString("Angle |  Pulse (us)  |  CCR1\r\n");
    USART2_SendString("------|-------------|-------\r\n");

    for (uint8_t angle = 0; angle <= 180; angle += 10)
    {
        uint32_t pulse_us = Servo_AngleToPulse(angle);

        Servo_SetAngle(angle);

        snprintf(buf, sizeof(buf),
                 "%3u   |    %4lu      |  %4lu\r\n",
                 angle,
                 (unsigned long)pulse_us,
                 (unsigned long)TIM2->CCR1);
        USART2_SendString(buf);

        delay_ms(500U);
    }

    Servo_SetAngle(90U);
    snprintf(buf, sizeof(buf),
             "\r\n-- Final Hold: 90 degrees --\r\nPulse = 1500 us  |  CCR1 = %lu\r\n",
             (unsigned long)TIM2->CCR1);
    USART2_SendString(buf);

    USART2_SendString("\r\n====== Task 6B Complete ======\r\n");

    while (1) {}
}
