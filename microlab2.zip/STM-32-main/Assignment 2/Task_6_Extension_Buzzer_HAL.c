/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (Task 6A - HAL Version FIXED)
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdio.h>
#include <string.h>

/* Private typedef -----------------------------------------------------------*/
typedef struct {
    const char *name;
    uint32_t arr;
    uint32_t dur;
} Note;

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim4;
UART_HandleTypeDef huart2;

volatile uint32_t ms_count = 0;

/* Part 1: C-Major Scale Data */
static const Note scale[] = {
    { "C4", 3436, 400 }, { "D4", 3061, 400 }, { "E4", 2727, 400 }, { "F4", 2572, 400 },
    { "G4", 2295, 400 }, { "A4", 2044, 400 }, { "B4", 1821, 400 }, { "C5", 1717, 400 }
};

/* Part 2: Nokia Tune Data */
static const Note melody[] = {
    { "E5", 1364, 150 }, { "D5", 1532, 150 }, { "F#4", 2431, 300 }, { "G#4", 2021, 300 },
    { "C#5", 1607, 150 }, { "B4", 1821, 150 }, { "D4", 3061, 300 }, { "E4", 2727, 300 },
    { "B4", 1821, 150 }, { "A4", 2044, 150 }, { "C#4", 3436, 300 }, { "E4", 2727, 300 },
    { "A4", 2044, 600 }
};

#define SCALE_LEN  (sizeof(scale) / sizeof(scale[0]))
#define MELODY_LEN (sizeof(melody) / sizeof(melody[0]))

/* Prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM4_Init(void);
static void MX_USART2_UART_Init(void);
void delay_ms(uint32_t ms);
void PlayNote(uint32_t arr, uint32_t duration);
void REST(uint32_t ms);

/* --- User Code --- */
void delay_ms(uint32_t ms) {
    uint32_t start = ms_count;
    while((ms_count - start) < ms);
}

void PlayNote(uint32_t arr, uint32_t duration) {
    // 1. Update values while timer is running (Preload handles the transition)
    __HAL_TIM_SET_AUTORELOAD(&htim4, arr);
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, arr / 2);

    // 2. Force immediate latch of the new frequency
    htim4.Instance->EGR = TIM_EGR_UG;

    // 3. Ensure the counter didn't get stuck above the new ARR
    if (htim4.Instance->CNT >= arr) {
        htim4.Instance->CNT = 0;
    }

    delay_ms(duration);

    // 4. Silence by setting duty cycle to 0, NOT by stopping the timer
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
}

void REST(uint32_t ms) {
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
    delay_ms(ms);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if(htim->Instance == TIM2) {
        ms_count++;
    }
}

int main(void)
{
  char buf[100];

  HAL_Init();
  SystemClock_Config();

  /* CRITICAL: GPIO must be ready before Timers */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_TIM4_Init();

  /* Start TIM2 Tick */
  if (HAL_TIM_Base_Start_IT(&htim2) != HAL_OK) Error_Handler();

  // --- Part 1: Scale ---
  HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n-- Part 1: C-Major Scale --\r\n", 31, 100);
  for (uint8_t i = 0; i < SCALE_LEN; i++) {
      uint32_t arr = scale[i].arr;
      uint32_t f_actual = 900000UL / (arr + 1UL);
      snprintf(buf, sizeof(buf), "%-4s  | %5lu  |  %lu Hz\r\n", scale[i].name, arr, f_actual);
      HAL_UART_Transmit(&huart2, (uint8_t*)buf, strlen(buf), 100);
      PlayNote(arr, scale[i].dur);
      delay_ms(50);
  }

  HAL_Delay(1000); // Using HAL_Delay for the long 1s pause is safer

  // --- Part 2: Nokia Tune ---
  HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n-- Part 2: Nokia Tune --\r\n", 28, 100);
  for(uint8_t i = 0; i < MELODY_LEN; i++) {
      snprintf(buf, sizeof(buf), "%-4s  | %5lu  |  %lu ms\r\n", melody[i].name, melody[i].arr, melody[i].dur);
      HAL_UART_Transmit(&huart2, (uint8_t*)buf, strlen(buf), 100);
      PlayNote(melody[i].arr, melody[i].dur);
      REST(40);
  }

  HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n====== Task 6A Complete ======\r\n", 34, 100);

  while (1) {
      // Done.
  }
}

/* Peripheral Initializations (Verified for 180MHz) */
void SystemClock_Config(void) {
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);
  HAL_PWREx_EnableOverDrive();
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5);
}

static void MX_TIM2_Init(void) {
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 89;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  HAL_TIM_Base_Init(&htim2);
  HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM2_IRQn);
}

static void MX_TIM4_Init(void) {
  TIM_OC_InitTypeDef sConfigOC = {0};

  __HAL_RCC_TIM4_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 99;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 999;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  HAL_TIM_PWM_Init(&htim4);

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1);

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP; // Alternate Function Push-Pull
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF2_TIM4;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Start the timer once and leave it running
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
}

static void MX_USART2_UART_Init(void) {
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.Mode = UART_MODE_TX_RX;
  HAL_UART_Init(&huart2);
}

static void MX_GPIO_Init(void) {
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
}

void Error_Handler(void) {
  __disable_irq();
  while (1) {}
}
